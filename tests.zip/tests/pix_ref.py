# Reference of Pix.kt (v2.5): script-style PIXEL SEARCH. Same rules as the Kotlin code, so it can be tested on the screenshots here.
import numpy as np, cv2
FISH, EXIT, XBTN = 1, 2, 4

def mask_of(kind, R, G, B):
    R = R.astype(int); G = G.astype(int); B = B.astype(int)
    if kind == FISH:   # blue-violet accent of the Fish button
        return (B >= 95) & (R >= 50) & (B - R >= 28) & (B - G >= 22) & (R <= 150)
    if kind == EXIT:   # salmon-red accent of the Exit button
        return (R >= 60) & (R - G >= 12) & (R - B >= 0) & (G <= 190)
    # XBTN: white
    mx = np.maximum(np.maximum(R, G), B); mn = np.minimum(np.minimum(R, G), B)
    return (mn >= 215) & (mx - mn <= 35)

def components(m, cell, rad, minact):
    h, w = m.shape; ch = h // cell; cw = w // cell
    if ch < 1 or cw < 1: return []
    cnt = m[:ch*cell, :cw*cell].reshape(ch, cell, cw, cell).sum((1, 3))
    act = cnt >= minact
    seen = np.zeros_like(act); out = []
    for cy in range(ch):
        for cx in range(cw):
            if not act[cy, cx] or seen[cy, cx]: continue
            st = [(cy, cx)]; seen[cy, cx] = True; cells = []
            while st:
                y, x = st.pop(); cells.append((y, x))
                for dy in range(-rad, rad+1):
                    for dx in range(-rad, rad+1):
                        yy, xx = y+dy, x+dx
                        if 0 <= yy < ch and 0 <= xx < cw and act[yy, xx] and not seen[yy, xx]:
                            seen[yy, xx] = True; st.append((yy, xx))
            ys = [c[0] for c in cells]; xs = [c[1] for c in cells]
            x0, x1 = min(xs)*cell, (max(xs)+1)*cell; y0, y1 = min(ys)*cell, (max(ys)+1)*cell
            out.append((x0, y0, x1, y1, int(sum(cnt[c] for c in cells))))
    return out

def find_button(rgb, kind):
    R, G, B = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    m = mask_of(kind, R, G, B); h, w = m.shape; best = None
    cell = max(4, w // 160)
    for x0, y0, x1, y1, n in components(m, cell, 2, 2):
        bw, bh = x1-x0, y1-y0
        if bw < 40 or bh < 8 or n < 60: continue
        asp = bw / bh
        if asp < 3.5 or asp > 9.0: continue
        sub = rgb[y0:y1, x0:x1].astype(int); lum = (sub[..., 0]*3 + sub[..., 1]*6 + sub[..., 2]) // 10
        if lum.mean() > 85: continue          # a button sits on a dark panel
        if best is None or n > best[2]: best = ((x0+x1)//2, (y0+y1)//2, n)
    return best

def find_x(rgb):
    R, G, B = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    m = mask_of(XBTN, R, G, B); h, w = m.shape; lim = int(h*0.6); m2 = m[:lim]
    best = None
    for x0, y0, x1, y1, n in components(m2, 3, 1, 1):
        bw, bh = x1-x0, y1-y0
        if bw < 10 or bh < 10 or bw > 160 or bh > 160: continue
        if not (0.75 <= bw/bh <= 1.33): continue
        if (x0+x1)/2 < w*0.45: continue
        fill = n / float(bw*bh)
        if fill < 0.06 or fill > 0.5: continue
        def on(px, py):
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    yy, xx = py+dy, px+dx
                    if 0 <= yy < lim and 0 <= xx < w and m2[yy, xx]: return True
            return False
        ok = 0; tot = 0
        for i in range(1, 10):
            t = 0.15 + 0.7*(i-1)/8.0
            px = int(x0 + t*(bw-1)); py = int(y0 + t*(bh-1)); qx = int(x1-1 - t*(bw-1))
            tot += 2; ok += on(px, py) + on(qx, py)
        if ok < tot*0.75: continue
        cx, cy = (x0+x1)//2, (y0+y1)//2
        edges = on(cx, y0+1) + on(cx, y1-2) + on(x0+1, cy) + on(x1-2, cy)
        if edges > 1: continue
        ci = max(1, int(0.12*min(bw, bh)))
        if not (on(x0+ci, y0+ci) and on(x1-1-ci, y0+ci) and on(x0+ci, y1-1-ci) and on(x1-1-ci, y1-1-ci)): continue
        # the X stands alone: no other white close around it (letters of a text have neighbours)
        mg = max(3, int(0.3*max(bw, bh)))
        ya, yb, xa, xb = max(0, y0-mg), min(lim, y1+mg), max(0, x0-mg), min(w, x1+mg)
        ring = int(m2[ya:yb, xa:xb].sum()) - int(m2[y0:y1, x0:x1].sum())
        if ring > 0.02*((yb-ya)*(xb-xa) - bw*bh): continue
        score = (x0+x1)/2 - (y0+y1)/2*0.5
        if best is None or score > best[2]: best = (cx, cy, score)
    return best

def find(rgb, want):
    out = None
    if want & FISH:
        b = find_button(rgb, FISH)
        if b and (out is None or b[2] > out[3]): out = (FISH, b[0], b[1], b[2])
    if want & EXIT:
        b = find_button(rgb, EXIT)
        if b and (out is None or b[2] > out[3]): out = (EXIT, b[0], b[1], b[2])
    if want & XBTN:
        b = find_x(rgb)
        if b: out = (XBTN, b[0], b[1], 10**6)   # a seen X outranks the buttons (a result box covers them)
    return out
