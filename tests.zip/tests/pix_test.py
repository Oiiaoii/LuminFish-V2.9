# v2.5 desktop check of the PIXEL RECOGNITION (same rules as Pix.kt, see pix_ref.py), run on the 5 screenshots at several sizes + noise.
import cv2, numpy as np, os, sys
sys.path.insert(0, os.path.dirname(__file__)); import pix_ref as P
F = os.path.join(os.path.dirname(__file__), 'fixtures') + '/'
want = {'1_fish': P.FISH, '2_exit': P.EXIT, '3_minigame': None, '4_failed': P.XBTN, '5_caught': P.XBTN}
rng = np.random.default_rng(1); bad = 0; tot = 0
for sc in (0.3, 0.35, 0.4, 0.5, 0.6, 0.7, 0.8, 1.0, 1.2, 1.4):
    for n, w in want.items():
        im = cv2.resize(cv2.imread(F + n + '.png'), None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA).astype(float)
        im = np.clip(im * 0.93 + rng.normal(0, 4, im.shape), 0, 255).astype('uint8')
        r = P.find(im[..., ::-1], 7); k = r[0] if r else None; tot += 1
        if k != w: bad += 1; print('WRONG', sc, n, k)
print('pixel recognition:', tot - bad, '/', tot)
print('ALL OK' if bad == 0 else 'FAILED'); raise SystemExit(0 if bad == 0 else 1)
